import React from 'react'

const Gilgit = () => {
  
  return (
    
    <div className='container'>
      <div class="main">




<h2><i>Gilgit Projects Gallery</i></h2>


<div class="row">
  <div class="column">
    <div class="content">
      <img src="/images/gilgit.jpg" alt="Mountains" style={{width:'100%'}} />
      <h3>Detail No : 1</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="/images/gilgit.jpg" alt="Lights" style={{width:'100%'}} />
      <h3>Detail No : 2</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
  <div class="column">
    <div class="content">
    <img src="/images/gilgit.jpg" alt="Nature" style={{width:'100%'}} />
      <h3>Detail No : 3</h3>
      <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
    </div>
  </div>
</div>

<div class="content">
  <img src="/images/gilgit.jpg" alt="Bear" style={{width:'100%'}} />
  <h3>Main Project</h3>
  <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
  <p>Lorem ipsum dolor sit amet, tempor prodesset eos no. Temporibus necessitatibus sea ei, at tantas oporteat nam. Lorem ipsum dolor sit amet, tempor prodesset eos no.</p>
</div>


</div>

    </div>

  )
}

export default Gilgit
