import React from 'react'

const NoPage = () => {
  return (
    <div>
        <br></br>
      <h1>No Page Found</h1>
    </div>
  )
}

export default NoPage
