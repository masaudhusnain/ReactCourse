import { createContext } from "react";

const InformationContext = createContext();

export default InformationContext ;